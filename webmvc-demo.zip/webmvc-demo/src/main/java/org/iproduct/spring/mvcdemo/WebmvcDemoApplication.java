package org.iproduct.spring.mvcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebmvcDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebmvcDemoApplication.class, args);
	}
}
