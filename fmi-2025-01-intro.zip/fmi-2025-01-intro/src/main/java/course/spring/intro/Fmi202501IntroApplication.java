package course.spring.intro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fmi202501IntroApplication {

	public static void main(String[] args) {
		SpringApplication.run(Fmi202501IntroApplication.class, args);
	}

}
