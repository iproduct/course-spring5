package org.iproduct.spring.restmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestMvcApplication.class, args);
	}
}
