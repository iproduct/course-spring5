package org.iproduct.webflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxDemoLab8Application {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxDemoLab8Application.class, args);
	}

}
